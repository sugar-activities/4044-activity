#!/bin/sh
sugar-activity activity.flipsticksActivity